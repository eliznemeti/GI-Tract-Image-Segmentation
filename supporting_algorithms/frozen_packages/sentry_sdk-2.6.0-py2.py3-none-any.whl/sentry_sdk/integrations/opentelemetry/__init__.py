from sentry_sdk.integrations.opentelemetry.span_processor import (  # noqa: F401
    SentrySpanProcessor,
)

from sentry_sdk.integrations.opentelemetry.propagator import (  # noqa: F401
    SentryPropagator,
)
