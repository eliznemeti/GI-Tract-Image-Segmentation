from pytorch_lightning.demos.transformer import LightningTransformer, Transformer, WikiText2  # noqa: F401
