from flash.graph.classification import GraphClassificationData, GraphClassifier  # noqa: F401
from flash.graph.embedding import GraphEmbedder  # noqa: F401
