from flash.graph.classification.data import GraphClassificationData  # noqa: F401
from flash.graph.embedding.model import GraphEmbedder  # noqa: F401
