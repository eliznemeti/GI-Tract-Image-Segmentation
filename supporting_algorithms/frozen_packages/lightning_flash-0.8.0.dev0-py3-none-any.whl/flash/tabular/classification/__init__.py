from flash.tabular.classification.data import TabularClassificationData  # noqa: F401
from flash.tabular.classification.model import TabularClassifier  # noqa: F401
