from flash.tabular.regression.data import TabularRegressionData  # noqa: F401
from flash.tabular.regression.model import TabularRegressor  # noqa: F401
