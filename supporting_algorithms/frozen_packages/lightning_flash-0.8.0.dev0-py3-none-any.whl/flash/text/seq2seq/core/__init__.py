from flash.text.seq2seq.core.model import Seq2SeqTask  # noqa: F401
