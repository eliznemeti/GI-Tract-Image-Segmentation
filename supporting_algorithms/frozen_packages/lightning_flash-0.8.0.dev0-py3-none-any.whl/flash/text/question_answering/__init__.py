from flash.text.question_answering.data import QuestionAnsweringData  # noqa: F401
from flash.text.question_answering.model import QuestionAnsweringTask  # noqa: F401
