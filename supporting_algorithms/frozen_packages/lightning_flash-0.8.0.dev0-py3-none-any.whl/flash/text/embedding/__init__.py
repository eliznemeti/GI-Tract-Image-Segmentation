from flash.text.embedding.model import TextEmbedder  # noqa: F401
