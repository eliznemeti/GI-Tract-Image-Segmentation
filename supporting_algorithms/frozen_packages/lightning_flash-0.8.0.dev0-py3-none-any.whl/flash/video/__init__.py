from flash.video.classification.data import VideoClassificationData  # noqa: F401
from flash.video.classification.model import VideoClassifier  # noqa: F401
