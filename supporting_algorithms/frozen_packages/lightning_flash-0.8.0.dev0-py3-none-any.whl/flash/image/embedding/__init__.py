from flash.image.embedding.model import ImageEmbedder  # noqa: F401
