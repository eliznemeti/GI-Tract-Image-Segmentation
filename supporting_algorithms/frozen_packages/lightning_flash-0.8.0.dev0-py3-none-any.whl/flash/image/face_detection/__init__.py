from flash.image.face_detection.data import FaceDetectionData  # noqa: F401
from flash.image.face_detection.model import FaceDetector  # noqa: F401
