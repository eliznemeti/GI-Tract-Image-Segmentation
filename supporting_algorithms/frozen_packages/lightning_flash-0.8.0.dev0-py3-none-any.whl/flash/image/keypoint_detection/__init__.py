from flash.image.keypoint_detection.data import KeypointDetectionData  # noqa: F401
from flash.image.keypoint_detection.model import KeypointDetector  # noqa: F401
