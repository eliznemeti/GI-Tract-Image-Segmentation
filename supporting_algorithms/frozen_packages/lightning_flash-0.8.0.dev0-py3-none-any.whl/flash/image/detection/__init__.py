from flash.image.detection.data import ObjectDetectionData  # noqa: F401
from flash.image.detection.model import ObjectDetector  # noqa: F401
