from flash.image.instance_segmentation.data import InstanceSegmentationData  # noqa: F401
from flash.image.instance_segmentation.model import InstanceSegmentation  # noqa: F401
