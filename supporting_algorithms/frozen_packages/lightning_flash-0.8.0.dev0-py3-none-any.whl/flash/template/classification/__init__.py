from flash.template.classification.data import TemplateData  # noqa: F401
from flash.template.classification.model import TemplateSKLearnClassifier  # noqa: F401
