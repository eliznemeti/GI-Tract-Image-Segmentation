from flash.template.classification import TemplateData, TemplateSKLearnClassifier  # noqa: F401
