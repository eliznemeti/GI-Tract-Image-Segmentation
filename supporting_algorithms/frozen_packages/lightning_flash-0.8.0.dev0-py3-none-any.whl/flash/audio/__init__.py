from flash.audio.classification import AudioClassificationData, AudioClassificationInputTransform  # noqa: F401
from flash.audio.speech_recognition import SpeechRecognition, SpeechRecognitionData  # noqa: F401
