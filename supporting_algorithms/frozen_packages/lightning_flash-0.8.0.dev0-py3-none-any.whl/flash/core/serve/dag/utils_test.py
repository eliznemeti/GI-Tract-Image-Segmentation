def inc(x):
    return x + 1


def add(x, y):
    return x + y


def mul(x, y):
    return x * y
