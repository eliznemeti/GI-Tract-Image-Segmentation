from flash.core.serve._compat.cached_property import cached_property

__all__ = ("cached_property",)
